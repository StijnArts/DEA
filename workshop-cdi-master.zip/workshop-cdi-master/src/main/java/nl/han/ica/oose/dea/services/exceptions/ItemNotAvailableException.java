package nl.han.ica.oose.dea.services.exceptions;

public class ItemNotAvailableException extends RuntimeException {
}
