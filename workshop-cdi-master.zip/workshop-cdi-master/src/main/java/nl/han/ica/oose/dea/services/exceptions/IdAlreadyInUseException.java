package nl.han.ica.oose.dea.services.exceptions;

public class IdAlreadyInUseException extends RuntimeException {
}
