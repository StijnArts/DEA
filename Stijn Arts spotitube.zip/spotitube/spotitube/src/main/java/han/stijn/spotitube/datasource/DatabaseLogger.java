package han.stijn.spotitube.datasource;

import java.util.logging.*;

public class DatabaseLogger {
    protected Logger logger = Logger.getLogger(getClass().getName());
}
